package prob3;

//implement as necessary
public abstract class LibraryMember {
	//Declare an abstract method so that faculty and student should implement it
	abstract public CheckoutRecord getRecord();

}
